import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-plan',
  templateUrl: './add-plan.component.html',
  styleUrls: ['./add-plan.component.scss']
})
export class AddPlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
