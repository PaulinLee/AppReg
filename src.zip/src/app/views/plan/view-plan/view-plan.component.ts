import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-plan',
  templateUrl: './view-plan.component.html',
  styleUrls: ['./view-plan.component.scss']
})
export class ViewPlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
