import { Component, OnInit } from '@angular/core';
import { FormBuilder , FormGroup} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

 loginForm:FormGroup

  constructor(private formBuilder: FormBuilder) {
  this.loginForm = this.formBuilder.group({
      materialLoginFormEmail: '',
      materialLoginFormPassword: ''
    }); }

  showNav = true;
  ngOnInit() {
  }

login() {
    console.log("login click");

}
}
